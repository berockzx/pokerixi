// dummy spixi-app-sdk.js content for placeholder
