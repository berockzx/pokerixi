// dummy spixi-tools.js content for placeholder
